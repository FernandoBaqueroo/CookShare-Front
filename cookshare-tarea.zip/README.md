# CookShare 🍪

CookShare es una aplicación web moderna para compartir y descubrir recetas de cocina. Desarrollada con React y Vite, ofrece una experiencia de usuario fluida con animaciones suaves y un diseño atractivo.

## 🚀 Características

- **Interfaz moderna**: Diseño responsive con gradientes y efectos de glassmorphism
- **Animaciones suaves**: Transiciones fluidas y animaciones CSS personalizadas
- **Navegación intuitiva**: Barra de navegación fija con indicadores visuales
- **Autenticación**: Sistema de login y registro
- **Feed de recetas**: Visualización de recetas con interacciones sociales
- **Responsive**: Optimizado para móviles, tablets y desktop

## 🛠️ Tecnologías Utilizadas

- **Frontend**: React 18 + Vite
- **Routing**: React Router DOM
- **Estilos**: Tailwind CSS con configuración personalizada
- **Iconos**: Lucide React
- **Animaciones**: CSS personalizado con keyframes
- **Estado**: React Hooks (useState, useEffect, useContext)

## 📋 Prerrequisitos

Antes de comenzar, asegúrate de tener instalado:

- **Node.js** (versión 16 o superior)
- **npm** o **yarn** (gestor de paquetes)

### Verificar instalación:
```bash
node --version
npm --version
```

## 🚀 Instalación y Configuración

### 1. Clonar el repositorio
```bash
git clone <url-del-repositorio>
cd cookshare-front
```

### 2. Instalar dependencias
```bash
npm install
```

### 3. Configurar variables de entorno (opcional)
Si necesitas configurar variables de entorno, crea un archivo `.env` en la raíz del proyecto:
```bash
cp .env.example .env
```

### 4. Ejecutar en modo desarrollo
```bash
npm run dev
```

La aplicación estará disponible en: `http://localhost:5173`

### 5. Construir para producción
```bash
npm run build
```

### 6. Previsualizar build de producción
```bash
npm run preview
```

## 📁 Estructura del Proyecto

```
cookshare-front/
├── public/
│   └── images/
│       └── logo/
│           └── LogoCookie.png
├── src/
│   ├── components/
│   │   ├── Feed.jsx
│   │   ├── HomePage.jsx
│   │   ├── Login/
│   │   │   ├── LoginCard.jsx
│   │   │   ├── LoginDecor.jsx
│   │   │   └── LoginForm.jsx
│   │   ├── Login.jsx
│   │   ├── Navbar/
│   │   │   ├── NavbarDesktop.jsx
│   │   │   ├── NavbarItem.jsx
│   │   │   ├── NavbarLogo.jsx
│   │   │   └── NavbarMobile.jsx
│   │   ├── Navbar.jsx
│   │   ├── Register/
│   │   │   ├── RegisterCard.jsx
│   │   │   ├── RegisterDecor.jsx
│   │   │   └── RegisterForm.jsx
│   │   └── Register.jsx
│   ├── functions/
│   │   └── api.js
│   ├── hooks/
│   │   └── useAuth.js
│   ├── App.css
│   ├── App.jsx
│   └── main.jsx
├── package.json
├── vite.config.js
└── README.md
```

## 🎨 Paleta de Colores

El proyecto utiliza una paleta personalizada de colores "Pavlova":

- **Pavlova-50**: #faf7f2 (Fondo principal)
- **Pavlova-100**: #f4eee0 (Fondo secundario)
- **Pavlova-200**: #e8dac0 (Bordes y separadores)
- **Pavlova-300**: #dbc49b (Elementos interactivos)
- **Pavlova-400**: #caa36d (Acentos)
- **Pavlova-500**: #be8c51 (Botones principales)
- **Pavlova-600**: #b17845 (Hover states)
- **Pavlova-700**: #93603b (Texto importante)
- **Pavlova-800**: #774f35 (Títulos)
- **Pavlova-900**: #61412d (Texto principal)

## 🎭 Animaciones

El proyecto incluye animaciones CSS personalizadas:

- **fade-in-up**: Entrada desde abajo con fade
- **fade-in-down**: Entrada desde arriba con fade
- **scale-in**: Escalado suave
- **float**: Efecto flotante
- **pulse-slow**: Pulso lento
- **stagger-X**: Entrada escalonada

## 📱 Rutas Disponibles

- `/` - Página de inicio
- `/login` - Página de login
- `/register` - Página de registro
- `/feed` - Feed de recetas
- `/perfil` - Perfil de usuario (en desarrollo)
- `/crear` - Crear receta (en desarrollo)
- `/favoritos` - Recetas favoritas (en desarrollo)

## 🔧 Scripts Disponibles

```bash
npm run dev          # Ejecutar en modo desarrollo
npm run build        # Construir para producción
npm run preview      # Previsualizar build
npm run lint         # Ejecutar ESLint
```

## 🐛 Solución de Problemas

### Error de puerto ocupado
Si el puerto 5173 está ocupado, Vite automáticamente usará el siguiente puerto disponible.

### Problemas de dependencias
```bash
rm -rf node_modules package-lock.json
npm install
```

### Problemas de cache
```bash
npm run dev -- --force
```

## 🤝 Contribución

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

## 👥 Autores

- **Tu Nombre** - *Desarrollo inicial* - [TuUsuario](https://github.com/TuUsuario)

## 🙏 Agradecimientos

- [Vite](https://vitejs.dev/) por el bundler rápido
- [Tailwind CSS](https://tailwindcss.com/) por el framework de CSS
- [Lucide](https://lucide.dev/) por los iconos
- [React Router](https://reactrouter.com/) por el routing

---

⭐ Si este proyecto te gusta, ¡dale una estrella!
