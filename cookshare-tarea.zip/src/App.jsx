import { Routes, Route } from 'react-router-dom'
import { useAuth } from './hooks/useAuth'
import HomePage from './components/HomePage'
import Register from './components/Register'
import Login from './components/Login'
import Navbar from './components/Navbar'
import Feed from './components/Feed'

function App() {
  const { isAuthenticated, isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pavlova-50 via-pavlova-100 to-pavlova-200 flex items-center justify-center">
        <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 shadow-lg border border-pavlova-200/50 animate-scale-in">
          <div className="spinner w-12 h-12 mx-auto mb-4"></div>
          <p className="text-pavlova-600 text-center animate-pulse-slow">Cargando CookShare...</p>
          <div className="flex justify-center mt-4 space-x-1">
            <div className="w-2 h-2 bg-pavlova-400 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-pavlova-500 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
            <div className="w-2 h-2 bg-pavlova-600 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <>
      {isAuthenticated && <Navbar />}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/feed" element={<Feed />} />
        <Route path="/perfil" element={<div className="min-h-screen bg-pavlova-400 flex items-center justify-center animate-fade-in-up"><h1 className="text-2xl font-bold text-white">Perfil (En desarrollo)</h1></div>} />
        <Route path="/crear" element={<div className="min-h-screen bg-pavlova-400 flex items-center justify-center animate-fade-in-up"><h1 className="text-2xl font-bold text-white">Crear Receta (En desarrollo)</h1></div>} />
        <Route path="/favoritos" element={<div className="min-h-screen bg-pavlova-400 flex items-center justify-center animate-fade-in-up"><h1 className="text-2xl font-bold text-white">Favoritos (En desarrollo)</h1></div>} />
      </Routes>
    </>
  )
}

export default App