import { Link } from 'react-router-dom'
import { UtensilsCrossed, Heart, Search, Users, Star, MessageCircle } from 'lucide-react'

function HomePage() {
  const features = [
    {
      icon: UtensilsCrossed,
      title: "Comparte tus recetas",
      description: "Publica tus recetas favoritas con fotos atractivas, ingredientes detallados y pasos claros"
    },
    {
      icon: Search,
      title: "Descubre nuevas recetas",
      description: "Explora el feed cronológico y encuentra inspiración culinaria de la comunidad"
    },
    {
      icon: Heart,
      title: "Filtros inteligentes",
      description: "Busca recetas por ingredientes que tengas o palabras clave específicas"
    },
    {
      icon: Star,
      title: "Sistema de valoraciones",
      description: "Califica recetas y lee comentarios de otros cocineros para mejorar tus platos"
    },
    {
      icon: MessageCircle,
      title: "Comunidad colaborativa",
      description: "Comparte consejos, modificaciones y resultados con otros entusiastas de la cocina"
    },
    {
      icon: Users,
      title: "Registro gratuito",
      description: "Únete a nuestra comunidad gastronómica de forma completamente gratuita"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-pavlova-50 via-pavlova-100 to-pavlova-200">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-pavlova-400/20 to-pavlova-600/20" />
        <div className="relative z-10 container mx-auto px-4 py-8 sm:py-12 lg:py-16">
          <div className="text-center">
            <div className="flex items-center justify-center mb-6 animate-fade-in-down">
              <img 
                src="/images/logo/LogoCookie.png" 
                alt="CookShare Logo" 
                className="w-16 h-16 sm:w-20 sm:h-20 lg:w-24 lg:h-24 object-contain mr-1 animate-float"
              />
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-pavlova-800 animate-fade-in-right stagger-1">
                CookShare
              </h1>
            </div>
            <p className="text-xl sm:text-2xl lg:text-3xl text-pavlova-700 mb-4 max-w-3xl mx-auto animate-fade-in-up stagger-2">
              Comparte y descubre las mejores recetas de cocina
            </p>
            <p className="text-lg sm:text-xl text-pavlova-600 mb-8 max-w-2xl mx-auto animate-fade-in-up stagger-3">
              Únete a nuestra comunidad gastronómica donde los amantes de la cocina comparten sus creaciones favoritas
            </p>
            
            {/* Botones de acción */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up stagger-4">
              <Link
                to="/register"
                className="bg-gradient-to-r from-pavlova-500 to-pavlova-600 hover:from-pavlova-600 hover:to-pavlova-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover-lift"
              >
                Únete gratis
              </Link>
              <Link
                to="/login"
                className="bg-white/80 backdrop-blur-sm hover:bg-white text-pavlova-700 font-semibold py-3 px-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-pavlova-200 hover-lift"
              >
                Inicia sesión
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Sección de características */}
      <section className="py-16 sm:py-20 lg:py-24">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-pavlova-800 mb-6">
              ¿Por qué elegir CookShare?
            </h2>
            <p className="text-xl text-pavlova-600 max-w-3xl mx-auto">
              Una plataforma digital diseñada para entusiastas de la cocina que quieren compartir y descubrir recetas de forma fácil y organizada
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`bg-white/80 backdrop-blur-sm rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-pavlova-200/50 hover:border-pavlova-300 hover-lift animate-fade-in-up stagger-${index + 1}`}
              >
                <div className="bg-gradient-to-br from-pavlova-400 to-pavlova-600 rounded-full w-16 h-16 flex items-center justify-center mb-6 mx-auto transition-transform duration-300 hover:scale-110">
                  <feature.icon className="w-8 h-8 text-white transition-transform duration-300 hover:rotate-12" />
                </div>
                <h3 className="text-xl font-bold text-pavlova-800 mb-4 text-center">
                  {feature.title}
                </h3>
                <p className="text-pavlova-600 text-center leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sección de descripción detallada */}
      <section className="py-16 sm:py-20 bg-white/50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 sm:p-12 shadow-xl border border-pavlova-200/50 animate-scale-in">
              <h2 className="text-3xl sm:text-4xl font-bold text-pavlova-800 mb-8 text-center animate-fade-in-down">
                El corazón de CookShare
              </h2>
              
              <div className="space-y-8">
                <div className="flex flex-col lg:flex-row items-center gap-8 animate-fade-in-left stagger-1">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-pavlova-700 mb-4">
                      Feed principal cronológico
                    </h3>
                    <p className="text-pavlova-600 leading-relaxed">
                      Nuestro feed principal muestra las recetas publicadas por la comunidad ordenadas por recencia, 
                      permitiéndote explorar libremente el contenido y descubrir nuevas inspiraciones culinarias.
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-pavlova-400 to-pavlova-600 rounded-2xl p-6 w-full lg:w-64 h-48 flex items-center justify-center animate-float">
                    <Search className="w-16 h-16 text-white" />
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row-reverse items-center gap-8 animate-fade-in-right stagger-2">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-pavlova-700 mb-4">
                      Filtros inteligentes
                    </h3>
                    <p className="text-pavlova-600 leading-relaxed">
                      Utiliza nuestros filtros inteligentes para encontrar recetas específicas. 
                      Filtra por ingredientes que tengas disponibles o busca por palabras clave para tipos de platos particulares.
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-pavlova-400 to-pavlova-600 rounded-2xl p-6 w-full lg:w-64 h-48 flex items-center justify-center animate-float" style={{animationDelay: '0.5s'}}>
                    <Heart className="w-16 h-16 text-white" />
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row items-center gap-8 animate-fade-in-left stagger-3">
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-pavlova-700 mb-4">
                      Interacción y comunidad
                    </h3>
                    <p className="text-pavlova-600 leading-relaxed">
                      Cada receta tiene su página dedicada donde puedes calificarla con un sistema de estrellas, 
                      dejar comentarios sobre tus experiencias y ver las opiniones de otros cocineros. 
                      Esta interacción fomenta un entorno colaborativo para compartir consejos, modificaciones y resultados.
                    </p>
                  </div>
                  <div className="bg-gradient-to-br from-pavlova-400 to-pavlova-600 rounded-2xl p-6 w-full lg:w-64 h-48 flex items-center justify-center animate-float" style={{animationDelay: '1s'}}>
                    <MessageCircle className="w-16 h-16 text-white" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-16 sm:py-20">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-pavlova-800 mb-6 animate-fade-in-up">
            ¿Listo para empezar?
          </h2>
          <p className="text-xl text-pavlova-600 mb-8 max-w-2xl mx-auto animate-fade-in-up stagger-1">
            Únete a nuestra comunidad y comienza a compartir tus recetas favoritas con el mundo
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up stagger-2">
            <Link
              to="/register"
              className="bg-gradient-to-r from-pavlova-500 to-pavlova-600 hover:from-pavlova-600 hover:to-pavlova-700 text-white font-bold py-4 px-10 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 hover-lift"
            >
              Crear cuenta gratis
            </Link>
            <Link
              to="/login"
              className="bg-white/80 backdrop-blur-sm hover:bg-white text-pavlova-700 font-semibold py-4 px-10 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-pavlova-200 hover-lift"
            >
              Ya tengo cuenta
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default HomePage 