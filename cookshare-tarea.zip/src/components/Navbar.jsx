import { useLocation } from 'react-router-dom'
import { Home, User, Plus, Heart, LogOut } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import NavbarDesktop from './Navbar/NavbarDesktop'
import NavbarMobile from './Navbar/NavbarMobile'

function Navbar() {
  const location = useLocation()
  const { logout } = useAuth()

  const menuItems = [
    { path: '/feed', label: 'Feed', icon: Home },
    { path: '/perfil', label: 'Perfil', icon: User },
    { path: '/crear', label: 'Crear', icon: Plus },
    { path: '/favoritos', label: 'Favoritos', icon: Heart },
  ]

  const authPaths = ['/login', '/register', '/']
  const isActive = (path) => location.pathname === path
  const shouldHideNavbar = authPaths.includes(location.pathname)

  if (shouldHideNavbar) return null

  return (
    <>
      <NavbarDesktop menuItems={menuItems} isActive={isActive} onLogout={logout} />
      <NavbarMobile menuItems={menuItems} isActive={isActive} onLogout={logout} />
      <div className="lg:hidden h-20" />
    </>
  )
}

export default Navbar