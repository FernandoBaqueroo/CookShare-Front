function Feed() {
  

  return (
    <div className="min-h-screen bg-gradient-to-br from-pavlova-50 via-pavlova-100 to-pavlova-200 flex items-center justify-center animate-fade-in-up">
      <h1 className="text-2xl font-bold text-pavlova-800">Feed (En desarrollo)</h1>
    </div>
  )
}

export default Feed