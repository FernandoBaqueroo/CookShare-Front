import { useState } from 'react'
import LoginDecor from './Login/LoginDecor'
import LoginCard from './Login/LoginCard'
import LoginForm from './Login/LoginForm'
import { Link, useNavigate } from 'react-router-dom'
import { apiPost } from '../functions/api'

function Login() {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  })
  const [showPassword, setShowPassword] = useState(false)
  const [focusedField, setFocusedField] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [showModal, setShowModal] = useState(false)
  const navigate = useNavigate()

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    setResult(null)
    
    try {
      const res = await apiPost('login', formData)
      setResult(res)
      setShowModal(true)
      
      if (res.token) {
        localStorage.setItem('token', res.token)
        setTimeout(() => navigate('/feed'), 1800)
      }
    } catch (err) {
      setError(err.message)
      setShowModal(true)
    }
  }

  const handleModalClose = () => {
    setShowModal(false)
    if (result && !error) {
      navigate('/feed')
    }
  }

  const renderModalContent = () => {
    if (result && !error) {
      return (
        <>
          <div className="bg-gradient-to-br from-pavlova-400 to-pavlova-600 rounded-full p-4 mb-4 shadow-lg flex items-center justify-center animate-scale-in">
            <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-pavlova-700 mb-2 text-center animate-fade-in-up">
            ¡Inicio de sesión exitoso!
          </h2>
          <p className="text-pavlova-600 text-center mb-4 animate-fade-in-up stagger-1">
            Has iniciado sesión correctamente.<br/>Serás redirigido al feed en unos segundos.
          </p>
          <button onClick={handleModalClose} className="mt-2 px-4 py-2 rounded-lg bg-pavlova-500 hover:bg-pavlova-600 text-white font-semibold transition-all duration-300 transform hover:scale-105 hover-lift">
            Ir al feed
          </button>
        </>
      )
    }
    
    return (
      <>
        <div className="bg-gradient-to-br from-red-400 to-red-600 rounded-full p-4 mb-4 shadow-lg flex items-center justify-center animate-scale-in">
          <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </div>
        <h2 className="text-xl font-bold text-red-700 mb-2 text-center animate-fade-in-up">
          Error en el inicio de sesión
        </h2>
        <p className="text-red-600 text-center mb-4 animate-fade-in-up stagger-1">{error || 'Ha ocurrido un error inesperado.'}</p>
        <button onClick={() => setShowModal(false)} className="mt-2 px-4 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white font-semibold transition-all duration-300 transform hover:scale-105 hover-lift">
          Cerrar
        </button>
      </>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pavlova-100 via-pavlova-200 to-pavlova-300 flex items-center justify-center p-3 sm:p-4 relative overflow-hidden">
      <LoginDecor />
      <div className="w-full max-w-xs sm:max-w-sm md:max-w-md xl:max-w-xl 2xl:max-w-2xl flex items-center justify-center mx-auto animate-fade-in-up">
        <LoginCard>
          <LoginForm
            formData={formData}
            setFormData={setFormData}
            showPassword={showPassword}
            setShowPassword={setShowPassword}
            focusedField={focusedField}
            setFocusedField={setFocusedField}
            handleSubmit={handleSubmit}
          />
          <div className="text-center mt-3 sm:mt-4 lg:mt-4 xl:mt-5 2xl:mt-8 pt-2.5 sm:pt-3 lg:pt-3 xl:pt-4 2xl:pt-6 border-t border-pavlova-200/50 animate-fade-in-up stagger-1">
            <p className="text-pavlova-600 text-xs sm:text-xs lg:text-xs xl:text-xs 2xl:text-sm">
              ¿No tienes cuenta?{' '}
              <Link 
                to="/register" 
                className="text-pavlova-700 font-semibold hover:text-pavlova-900 transition-colors duration-200 hover:underline"
              >
                Regístrate aquí
              </Link>
            </p>
          </div>
        </LoginCard>
      </div>
      
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm animate-fade-in-up">
          <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-xs sm:max-w-sm w-full flex flex-col items-center animate-scale-in border-2 border-pavlova-200">
            {renderModalContent()}
          </div>
        </div>
      )}
      
      <div className="lg:hidden h-20" />
    </div>
  )
}

export default Login
