import NavbarItem from './NavbarItem'
import NavbarLogo from './NavbarLogo'

function NavbarDesktop({ menuItems, isActive }) {
  const headerClasses = "hidden lg:block fixed top-0 left-0 right-0 w-full z-50 bg-pavlova-100/80 backdrop-blur-md shadow-lg py-3 xl:py-5 border-b border-white/20"

  const renderMenuItems = (start, end) => (
    <div className="flex items-center gap-6 xl:gap-8 2xl:gap-12">
      {menuItems.slice(start, end).map((item) => (
        <NavbarItem
          key={item.path}
          to={item.path}
          icon={item.icon}
          label={item.label}
          active={isActive(item.path)}
        />
      ))}
    </div>
  )

  return (
    <header className={headerClasses}>
      <div className="container mx-auto px-4 xl:px-6">
        <nav className="flex justify-center items-center">
          <div className="flex items-center gap-8 xl:gap-12 2xl:gap-16">
            {renderMenuItems(0, 2)}
            <NavbarLogo />
            {renderMenuItems(2, 4)}
          </div>
        </nav>
      </div>
    </header>
  )
}

export default NavbarDesktop 