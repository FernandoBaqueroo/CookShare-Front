import { Link } from 'react-router-dom'

function NavbarLogo() {
  return (
    <Link 
      to="/" 
      className="group relative transition-all duration-300 hover:scale-105 focus:outline-none focus:ring-4 focus:ring-pavlova-300 rounded-full"
    >
      <div className="relative p-2 xl:p-3">
        <img
          src="/images/logo/LogoCookie.png"
          alt="CookShare Logo"
          className="w-16 h-16 xl:w-20 xl:h-20 rounded-full object-cover shadow-lg transition-all duration-300 group-hover:shadow-xl hover:rotate-12"
        />
        <div className="absolute inset-0 rounded-full bg-gradient-to-br from-pavlova-200/20 to-pavlova-400/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>
    </Link>
  )
}

export default NavbarLogo 