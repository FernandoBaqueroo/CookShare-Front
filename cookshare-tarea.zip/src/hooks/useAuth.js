import { useEffect, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigate()
  const location = useLocation()

  useEffect(() => {
    const token = localStorage.getItem('token')
    const hasToken = !!token
    
    setIsAuthenticated(hasToken)
    setIsLoading(false)

    // Rutas que requieren autenticación
    const protectedRoutes = ['/feed', '/perfil', '/crear', '/favoritos']
    // Rutas de autenticación
    const authRoutes = ['/login', '/register']
    
    const currentPath = location.pathname
    const isProtectedRoute = protectedRoutes.includes(currentPath)
    const isAuthRoute = authRoutes.includes(currentPath)

    if (hasToken) {
      // Si está autenticado y está en una ruta de auth, redirigir al feed
      if (isAuthRoute) {
        navigate('/feed', { replace: true })
      }
    } else {
      // Si no está autenticado y está en una ruta protegida, redirigir al home
      if (isProtectedRoute) {
        navigate('/', { replace: true })
      }
    }
  }, [location.pathname, navigate])

  const logout = () => {
    localStorage.removeItem('token')
    setIsAuthenticated(false)
    navigate('/', { replace: true })
  }

  return {
    isAuthenticated,
    isLoading,
    logout
  }
} 