const API_BASE = '/api/'

async function handleResponse(res) {
  const contentType = res.headers.get('content-type')
  
  if (contentType && contentType.includes('application/json')) {
    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}))
      throw new Error(errorData.message || `Error ${res.status}: ${res.statusText}`)
    }
    return await res.json()
  } else {
    // Si la respuesta es HTML (error de Laravel), crear un error apropiado
    if (!res.ok) {
      throw new Error(`Error ${res.status}: ${res.statusText}`)
    }
    throw new Error('Respuesta inesperada del servidor')
  }
}

export async function apiGet(endpoint, token) {
  const headers = token ? { Authorization: `Bearer ${token}` } : {}
  const res = await fetch(API_BASE + endpoint, { headers })
  return handleResponse(res)
}

export async function apiPost(endpoint, data, token) {
  const headers = { 'Content-Type': 'application/json' }
  if (token) headers.Authorization = `Bearer ${token}`
  const res = await fetch(API_BASE + endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(data)
  })
  return handleResponse(res)
}

export async function apiPut(endpoint, data, token) {
  const headers = { 'Content-Type': 'application/json' }
  if (token) headers.Authorization = `Bearer ${token}`
  const res = await fetch(API_BASE + endpoint, {
    method: 'PUT',
    headers,
    body: JSON.stringify(data)
  })
  return handleResponse(res)
}

export async function apiDelete(endpoint, token) {
  const headers = token ? { Authorization: `Bearer ${token}` } : {}
  const res = await fetch(API_BASE + endpoint, {
    method: 'DELETE',
    headers
  })
  return handleResponse(res)
} 